# The Text Back Vault
## 150 copy-paste replies for girls who do not know what to text back

For the girls who rewrite one reply 14 times before sending it.

Use this when you like him, but you do not want to sound desperate, dry, bitter, or like you rehearsed the message in your Notes app.

Find the situation. Copy the reply. Send it.

---

## Quick texting rule
If you feel anxious, do not send a paragraph. Send one confident sentence that does one of three things:

1. Adds playfulness
2. Asks for clarity
3. Moves the conversation forward

---

## 1. When he texts “wyd?”
1. “Trying to decide if I should be productive or dramatic. You?”
2. “Currently accepting better plans if you have any.”
3. “Depends who’s asking and what they’re offering.”
4. “Pretending I’m busy so I don’t look too available.”
5. “Waiting for someone to say something interesting. No pressure.”
6. “Nothing illegal yet. Why?”
7. “Thinking about making bad decisions, but I’m open to suggestions.”
8. “Chilling. But you texting me feels like a plot twist.”
9. “I was minding my business until you interrupted it.”
10. “Not much, but I feel like your answer better be more interesting than mine.”

## 2. When he finally texts back late
1. “Look who remembered they own a phone.”
2. “I was about to file a missing person report.”
3. “No worries, I only aged slightly waiting.”
4. “You’re lucky I’m in a generous mood.”
5. “I’ll allow the delayed response if the next message is good.”
6. “Interesting timing. I was almost about to act unbothered.”
7. “I respect the commitment to being mysterious.”
8. “Welcome back. Explain yourself in 3 words or less.”
9. “I was going to be dramatic but I’ll hear you out.”
10. “Okay, comeback message accepted. Barely.”

## 3. When the convo is getting dry
1. “Okay we’re dangerously close to small talk. Let’s fix that.”
2. “This convo needs a plot twist.”
3. “I feel like we’re both being too normal right now.”
4. “Give me your most random opinion. I’m judging silently.”
5. “Ask me something better before this turns into a customer service chat.”
6. “We need a more interesting topic immediately.”
7. “This is starting to feel like two coworkers on break.”
8. “New rule: no boring replies for the next 5 minutes.”
9. “I know you have better energy than this.”
10. “Let’s pretend we both have personalities for a second.”

## 4. When you want to flirt without being cringe
1. “I was trying to be chill but you’re making that difficult.”
2. “You’re kind of distracting. Annoying behavior honestly.”
3. “I don’t know if I like you or if you’re just good at texting. Suspicious.”
4. “You’re lucky you’re cute because that message was bold.”
5. “Careful, I might start expecting effort from you.”
6. “You’re doing a little too well right now.”
7. “I was going to ignore you for character development but here we are.”
8. “Not you slowly becoming my favorite notification.”
9. “You’re making it very hard to act normal.”
10. “I’ll admit it, that made me smile a little.”

## 5. When he asks “you miss me?”
1. “Don’t get cocky. But maybe a little.”
2. “I missed the entertainment, not the attitude.”
3. “You would love if I said yes.”
4. “Define miss. I noticed your absence dramatically.”
5. “A tiny amount. Don’t build a personality around it.”
6. “Unfortunately, yes. Keep that between us.”
7. “I missed having someone to bother me.”
8. “Maybe. Earn the full answer.”
9. “I plead the fifth.”
10. “You were missed in a very controlled, classy way.”

## 6. When he says “lol” or “haha”
1. “That laugh felt emotionally unavailable.”
2. “I need a stronger reaction than that.”
3. “Not the bare minimum laugh.”
4. “I know you can do better than ‘lol.’”
5. “That was a very customer-service response.”
6. “Blink twice if you’re being held hostage by dry texting.”
7. “I’m giving you one chance to redeem this reply.”
8. “That ‘lol’ had no seasoning.”
9. “I deserve at least a full sentence.”
10. “You’re lucky I’m carrying this conversation.”

## 7. When you want to ask him out casually
1. “We should continue this conversation somewhere that has food.”
2. “You seem like you’d be more fun in person. Prove me right.”
3. “I feel like this would be better over drinks.”
4. “I’m free this week if you want to stop being hypothetical.”
5. “We can keep texting or you can pick a day. Your call.”
6. “I want to see if your in-person energy matches your texts.”
7. “Coffee soon? Low pressure, high judgment.”
8. “This feels like a conversation that deserves fries.”
9. “Let’s test the chemistry outside this screen.”
10. “You should ask me to hang out before I act busy.”

## 8. When he compliments you
1. “Careful, compliments work on me.”
2. “That was smooth. I’ll give you that.”
3. “I was going to act humble but you’re not wrong.”
4. “Keep talking like that and I might get used to it.”
5. “That was cute. Slightly dangerous, but cute.”
6. “You’re making it hard to have standards.”
7. “I accept this compliment with zero chill.”
8. “Okay, that made me smile. Annoying.”
9. “Flattery will get you somewhere. Maybe.”
10. “That was actually sweet. I hate that it worked.”

## 9. When his energy is inconsistent
1. “I like consistency more than mystery, just so we’re clear.”
2. “You disappear a little too well for someone trying to be interesting.”
3. “I’m not mad, I just notice patterns.”
4. “I’m cool with slow replies, not mixed energy.”
5. “You can be busy, just don’t be confusing.”
6. “I like talking to you, but I’m not auditioning for attention.”
7. “Your energy is giving part-time crush.”
8. “I’m good with space. I’m not good with guessing.”
9. “If you’re interested, act like it. If not, no drama.”
10. “I’d rather know than overthink.”

## 10. When you sent something awkward
1. “Okay ignore my last message, my brain briefly left the chat.”
2. “That sounded better in my head. Restarting.”
3. “I’m choosing to pretend I said that smoother.”
4. “Not my finest text, but the intention was cute.”
5. “Let me rebrand that message real quick.”
6. “I promise I’m less awkward in person. Slightly.”
7. “That was my evil twin texting.”
8. “I panicked and pressed send. Growth opportunity.”
9. “Anyway, moving on before I embarrass myself professionally.”
10. “You saw nothing. New topic.”

## 11. When he asks “what are you looking for?”
1. “Something real, but not something forced.”
2. “Someone consistent, funny, and not allergic to effort.”
3. “I’m open, but I pay attention to energy.”
4. “A connection that feels easy but still intentional.”
5. “I’m not rushing anything, but I’m not here to waste time either.”
6. “Someone I can laugh with and actually trust.”
7. “Good energy, consistency, and a little tension.”
8. “I like when things feel natural but still have direction.”
9. “Something that does not make me question my sanity.”
10. “I’m figuring it out, but I know I like effort.”

## 12. When he sends a selfie
1. “Okay, that was unnecessary. Send another.”
2. “You knew exactly what you were doing.”
3. “I was having a normal day before this.”
4. “Respectfully, you’re a distraction.”
5. “That just changed the tone of the conversation.”
6. “I’m pretending to be normal about this.”
7. “You’re lucky I’m not easily impressed. Except I am.”
8. “This feels like a trap and I’m walking into it.”
9. “I need 3–5 business days to recover.”
10. “Okay cute. Annoyingly cute.”

## 13. When you want to text first
1. “I was going to wait for you to text first, but I got bored.”
2. “This is me pretending I’m not texting first.”
3. “I had a thought and unfortunately it involved you.”
4. “You crossed my mind. Don’t let it go to your head.”
5. “I’m making the executive decision to restart this conversation.”
6. “Hi. This is your chance to be interesting.”
7. “I was going to be mysterious but that sounds exhausting.”
8. “I feel like bothering you for a second.”
9. “You seem like trouble, so obviously I’m texting you.”
10. “Random question: are you always this distracting?”

## 14. When you need a boundary
1. “I like talking to you, but I need clearer energy than this.”
2. “I’m not upset, I just don’t do confusion for fun.”
3. “I’m okay taking things slow. I’m not okay feeling unsure all the time.”
4. “If we’re doing this, I need consistency.”
5. “I’m not asking for a lot, just honesty.”
6. “I like playful. I don’t like careless.”
7. “I’m cool with space, but communication matters to me.”
8. “I’m not chasing clarity. I’ll ask once.”
9. “I’m interested, but I’m also paying attention.”
10. “I’d rather keep it honest than keep guessing.”

## 15. When you want to end the convo without being rude
1. “I’m about to disappear into my night, but this was cute.”
2. “I need to be productive before I become a menace.”
3. “I’m going to go pretend I have discipline.”
4. “I’ll let you miss me for a bit.”
5. “I’m logging off before I say something too honest.”
6. “I have to go be a responsible adult unfortunately.”
7. “I’m going to sleep, but continue being interesting tomorrow.”
8. “This convo has earned a pause, not an ending.”
9. “I’ll talk to you later if you behave.”
10. “I’m leaving before I get too attached to this conversation.”

---

## When you need a custom reply
The vault gives you fast replies. Klarity gives you custom replies based on the actual conversation.

Paste the convo. Get options. Stop rewriting. Start replying.