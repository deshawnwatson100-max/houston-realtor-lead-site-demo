# README — The Text Back Vault

Product: The Text Back Vault
Price: $19 launch price
Audience: Gen Z girls / young women in talking stages
Promise: 150 copy-paste replies for girls who do not know what to text back.

## Upload these as the customer download
1. `the_text_back_vault.md` — main product file
2. `quick_start.txt` — simple customer instructions

## Use these for selling/posting
1. `checkout_page_copy.md` — paste into Gumroad/Stan/Beacons
2. `girl_first_launch_pack.md` — first 12 videos and posting order

## Fast setup
1. Create product page.
2. Upload `the_text_back_vault.md` and/or the zip.
3. Price at $19.
4. Bio line: `150 copy-paste replies for girls who don’t know what to text back ↓`
5. Start posting videos 1, 4, 3, 2, 5, 12 from the launch pack.
