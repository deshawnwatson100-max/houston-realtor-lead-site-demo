# Text Back Vault — Checkout Page Copy

## Product name
The Text Back Vault

## One-liner
150 copy-paste replies for when you do not know what to text back.

## Short description
For the moments when the convo gets dry, they finally text back, they send “wyd,” or you want to flirt without sounding desperate.

Open the vault, find the situation, copy the text, send it.

## Price
Launch price: $19

## What’s inside
- 150 ready-to-send texts
- 15 common dating/texting situations
- Flirty replies
- Late reply comebacks
- Dry convo savers
- “wyd?” replies
- Boundary texts
- Casual date invites
- First-text openers
- Awkward text recovery lines

## Who it is for
- You overthink replies
- You hate sounding dry
- You want to flirt better
- You want to sound confident without acting cold
- You reread one message 14 times before sending it

## CTA button
Get The Text Back Vault

## Product page headline options
1. Stop overthinking your next text.
2. 150 texts for when your mind goes blank.
3. Sound confident, flirty, and chill over text.

## TikTok bio line
150 copy-paste texts for when you don’t know what to say ↓

## Pinned comment
I made the vault with all 150 replies — link in bio.

## DM/comment keyword automation copy
“TEXT” auto-reply:
Here’s the Text Back Vault — 150 copy-paste replies for when you don’t know what to say: [LINK]

## Soft refund note
Because this is a digital instant-download product, all sales are final.

## Delivery note
After purchase, download the PDF/Google Doc immediately and keep it on your phone.