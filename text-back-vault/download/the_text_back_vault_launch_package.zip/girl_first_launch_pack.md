# The Text Back Vault — Girl-First Launch Pack

## Offer
**The Text Back Vault**  
150 copy-paste replies for girls who do not know what to text back.

## Price
$19 launch price

## Bio
150 copy-paste replies for girls who don’t know what to text back ↓

## Product page headline
Stop overthinking your next text.

## Product page subhead
For the girls who rewrite one reply 14 times before sending it. Get 150 ready-to-send texts for dry convos, late replies, “wyd,” flirting, boundaries, and awkward moments.

## Button
Get The Text Back Vault

---

# First 12 videos to post

## 1. Wyd
**Hook:** If he texts “wyd,” don’t say “nothing.”
**Show:**
- “Currently accepting better plans if you have any.”
- “Depends who’s asking and what they’re offering.”
- “Pretending I’m busy so I don’t look too available.”
**Caption:** I made a vault with 150 replies for girls who don’t know what to text back. Link in bio.

## 2. Late reply
**Hook:** When he finally texts back and you want to sound chill, not pressed.
**Show:**
- “Look who remembered they own a phone.”
- “I’ll allow the delayed response if the next message is good.”
- “I respect the commitment to being mysterious.”
**Caption:** Don’t send the paragraph. Send the line.

## 3. Dry convo
**Hook:** If the convo is dying but you still like him, steal these.
**Show:**
- “Okay we’re dangerously close to small talk. Let’s fix that.”
- “This convo needs a plot twist.”
- “Ask me something better before this turns into a customer service chat.”
**Caption:** Dry texting is fixable. Overthinking makes it worse.

## 4. Flirt without cringe
**Hook:** 3 texts that flirt without making it weird.
**Show:**
- “I was trying to be chill but you’re making that difficult.”
- “Not you slowly becoming my favorite notification.”
- “You’re making it very hard to act normal.”
**Caption:** Playful honesty > desperate paragraphs.

## 5. Rewrite 14 times
**Hook:** For the girls who rewrite one reply 14 times before sending it.
**Show:**
- screen recording of vault title
- scroll through categories
- show 3 examples
**Caption:** I made the thing I needed. 150 copy-paste replies in bio.

## 6. Inconsistent guy
**Hook:** If his energy is inconsistent, don’t beg for clarity. Say this.
**Show:**
- “I’m cool with slow replies, not mixed energy.”
- “You can be busy, just don’t be confusing.”
- “I’d rather know than overthink.”
**Caption:** Calm clarity hits harder than a paragraph.

## 7. Compliment
**Hook:** When he compliments you and you forget how to act normal.
**Show:**
- “Careful, compliments work on me.”
- “That was smooth. I’ll give you that.”
- “Flattery will get you somewhere. Maybe.”
**Caption:** Stop deflecting. Flirt back.

## 8. Text first
**Hook:** Texting first is not desperate if the text has confidence.
**Show:**
- “I was going to wait for you to text first, but I got bored.”
- “You crossed my mind. Don’t let it go to your head.”
- “I’m making the executive decision to restart this conversation.”
**Caption:** Send the text. Just don’t send a nervous one.

## 9. Ask him out
**Hook:** If you want to see him but don’t want to sound too eager.
**Show:**
- “We should continue this conversation somewhere that has food.”
- “You seem like you’d be more fun in person. Prove me right.”
- “We can keep texting or you can pick a day. Your call.”
**Caption:** Low-pressure confidence always wins.

## 10. Awkward recovery
**Hook:** Sent something awkward? Recover with one of these.
**Show:**
- “That sounded better in my head. Restarting.”
- “Let me rebrand that message real quick.”
- “I panicked and pressed send. Growth opportunity.”
**Caption:** You do not have to disappear for 3 business days.

## 11. Miss me
**Hook:** If he asks “you miss me?” don’t fold immediately.
**Show:**
- “Don’t get cocky. But maybe a little.”
- “A tiny amount. Don’t build a personality around it.”
- “Unfortunately, yes. Keep that between us.”
**Caption:** Flirty, not defeated.

## 12. Product pitch
**Hook:** I made 150 texts for girls who freeze when it’s time to reply.
**Show:**
- The Text Back Vault
- 15 situations
- 150 copy-paste replies
**Voiceover:** Wyd replies, late reply comebacks, dry convo savers, flirty texts, boundaries, first texts, and awkward recovery lines. Find the situation, copy the text, send it.
**Caption:** Launch price is $19. Link in bio.

---

# First posting order
1. Wyd
2. Flirt without cringe
3. Dry convo
4. Late reply
5. Rewrite 14 times
6. Product pitch

# Pinned comment
I put all 150 replies in the Text Back Vault — link in bio.

# Comment reply
It’s called The Text Back Vault — 150 copy-paste replies for girls who don’t know what to text back. Link in bio.
